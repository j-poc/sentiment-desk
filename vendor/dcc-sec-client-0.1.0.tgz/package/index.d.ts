export type SecOptions={app:string;maxBytes?:number;timeoutMs?:number;ttlSeconds?:number;refresh?:boolean;signal?:AbortSignal;connectionPath?:string;baseUrl?:string;token?:string};
export type SecResponse={body:Uint8Array;url:string;sha256:string;retrievedAt:string;completedAt:string;requestedAt:string;status:number;delivery:'network'|'cache'|'replay';receiptId:string;headers:Record<string,string>};
export class SharedSecError extends Error{code:string;status:number|undefined;httpStatus:number|undefined;retryAfter:string|undefined;headers:Record<string,string>;}
export function fetchSec(url:string,options:SecOptions):Promise<SecResponse>;
