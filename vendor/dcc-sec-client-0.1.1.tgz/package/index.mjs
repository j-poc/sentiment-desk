import {readFile,stat} from 'node:fs/promises';
import {resolve} from 'node:path';
import {fetchSec as remoteFetch,SharedSecError} from './remote.mjs';
export {SharedSecError};
export async function fetchSec(url,options){
 let config;
 if(options.baseUrl||options.token||process.env.DCC_SEC_URL||process.env.DCC_SEC_TOKEN){config={url:options.baseUrl??process.env.DCC_SEC_URL,token:options.token??process.env.DCC_SEC_TOKEN};}
 else{
  const path=resolve(options.connectionPath??process.env.DCC_SEC_CONNECTION??'.dcc-sec.json');
  try{const mode=await stat(path);if(mode.uid!==process.getuid()||(mode.mode&0o077))throw new Error();config=JSON.parse(await readFile(path,'utf8'));}
  catch{throw new SharedSecError('configuration_error','Shared SEC connection is missing, invalid or not owner-only (0600); no direct fallback.');}
  if(config.app!==options.app)throw new SharedSecError('configuration_error','Shared SEC connection belongs to another app.');
 }
 return remoteFetch(url,{...options,baseUrl:config.url,token:config.token});
}
